# -*- coding: utf-8 -*-

from selenium import webdriver
import time

driver = webdriver.Chrome('D:\\Data\\shared\\script\\python\\SCB\\webdriver\\chrome\\v80\\chromedriver.exe')
url = "https://www.chiphell.com"
driver.get(url)

time.sleep(3)

driver.quit()

