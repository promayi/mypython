# -*- coding: utf-8 -*-
# Author: Jeff.Jiang

import base64
import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname='192.168.123.7', port=22, username='ops', password='ops')
stdin, stdout, stderr = ssh.exec_command('echo "";echo "<<<df>>>";df;echo "";echo "<<<date>>>";date;echo "";echo "<<<script>>>";./df.sh;echo "";echo "<<<Network>>>";ifconfig | grep -A1 eth0')
print(stdout.read().decode())






