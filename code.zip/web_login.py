# -*- coding: utf-8 -*-
# Author: Jeff.Jiang
# website with login

from urllib import request
from urllib import parse
from http.cookiejar import CookieJar
import re

cookiejar = CookieJar()
handler = request.HTTPCookieProcessor(cookiejar)
opener = request.build_opener(handler)

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'
}

data = {
    'email': "promayijz@gmail.com",
    'passwd': "Jiang@Zhen2"
}

login_url = "https://www.cordcloud.org/auth/login"
req = request.Request(login_url, data=parse.urlencode(data).encode('utf-8'), headers=headers)
opener.open(req)

system_url = "https://www.cordcloud.org/user"
req = request.Request(system_url, headers=headers)
resp = opener.open(req)
#with open('cord.html', 'w', encoding='utf-8') as fp:
#    fp.write(resp.read().decode('utf-8'))
html = resp.read().decode("utf-8")
#pa = re.search(r"已用", html)
print(html)
#print(pa)

