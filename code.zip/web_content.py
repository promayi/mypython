# -*- coding: utf-8 -*-
# Author: Jeff.Jiang
# website without login

import urllib.request
import time

head = {}
head['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'
response = urllib.request.urlopen("http://192.168.123.7")
html = response.read().decode("utf-8")
print(html)