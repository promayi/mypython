# -*- coding: utf-8 -*-
# Author: Jeff.Jiang


import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import io
import sys

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'
}


sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
f = open('D:\\Data\\shared\\script\\python\\SCB\\file\\url.txt', 'r')
url = f.readlines()
length = len(url)
url_result_success = []
url_result_failed = []
for i in range(0, length):
    try:
        response = requests.get(url[i].strip(), headers=headers, verify=False, allow_redirects=True, timeout=5)
        if response.status_code != 200:
            raise requests.RequestException(u"Status code error: {}".format(response.status_code))
    except requests.RequestException as e:
        url_result_failed.append(url[i])
        continue
    url_result_success.append(url[i])
f.close()

result_len1 = len(url_result_failed)
result_len2= len(url_result_success)

print("   ")
for i in range(0,result_len1):
    print (url_result_failed[i].strip()+"打开失败")
print("   ")
for j in range(0,result_len2):
	print (url_result_success[j].strip()+"打开成功")

